# TReX
 *A Lua Based Self-Healing System for Achaea*
 - https://www.achaea.com
 - https://www.ironrealms.com
 - https://www.youtube.com/watch?v=Bwxqzt-qKFo

## Requirements
 - Mudlet 3.7.1 +
 - http://mudlet.org
 - https://github.com/Mudlet/Mudlet#mudlet
 
### Features
 - Serverside/GMCP
 - Multiclass ready
 - Modularly developed
 - Designed for combat
 
